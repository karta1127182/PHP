<?php
require __DIR__. '/__cred.php';
$page_name = 'index';

?>
<?php include __DIR__. '/__htmlheader.php';  ?>
<?php include __DIR__. '/__navbar.php';  ?>
<div class="container">


</div>
<?php include __DIR__. '/__htmlfoot.php';  ?>