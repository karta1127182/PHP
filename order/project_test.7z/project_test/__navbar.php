<style>
    ul.navbar-nav>li.nav-item.active {
        background-color: #33FFFF;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">

                <li class="nav-item <?= $page_name == 'order_list' ? 'active' : '' ?>">
                    <a class="nav-link" href="order_list.php">訂單查詢</a>
                </li>
                <!-- <li class="nav-item <?= $page_name == 'order_detail_list' ? 'active' : '' ?>">
                    <a class="nav-link" href="order_detail_list.php">訂單明細列表</a>
                </li> -->

                <li class="nav-item <?= $page_name == 'order_insert' ? 'active' : '' ?>">
                    <a class="nav-link" href="order_insert.php">新增訂單資料</a>
                </li>

                <li class="nav-item <?= $page_name == 'order_detail_insert' ? 'active' : '' ?>">
                    <a class="nav-link" href="order_detail_insert.php">新增訂單明細資料</a>
                </li>

                <!-- <li class="nav-item <?= $page_name == 'logout' ? 'active' : '' ?>">
                    <a class="nav-link" href="logout.php">登出</a>
                </li> -->
            </ul>

        </div>
    </div>
</nav> 