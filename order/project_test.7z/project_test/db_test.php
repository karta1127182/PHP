<?php
include __DIR__. '/__connect_db.php';

try{$stmt = $pdo ->query("SELECT * FROM `order`");
}catch(PDOException $ex){
    echo $ex->getMessage();
}

while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
    print_r($row);
    echo'<br>';
}
//抓取欄位名稱
//$row = $stmt -> fetch(PDO::FETCH_ASSOC);
//抓取欄位索引值
//$row = $stmt -> fetch(PDO::FETCH_NUM);
//抓取欄位名稱&索引值
//$row = $stmt -> fetch(PDO::FETCH_BOTH);

//echo $row['name'];